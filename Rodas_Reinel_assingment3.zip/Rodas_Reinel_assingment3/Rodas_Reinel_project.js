var nickname = "\"Death Touch\".",
	bow = "Elf bow",
	dagger = "Azurah's Dagger",
	king = "\"Michael III\"",
	guards = 3,
	castle = "Castle Aurora",
	manyguards = true,
					// objects
	eliteguards = { eliteBlack1 : "Hard To Kill", 
					eliteWhite2 : "Easy to Kill",
					eliteWeapons : [ 
					"Magic Sword", 
					"Ruby Crossbow"
					] 
				};
var peopleIspeare = [ "Princess Leandra",
					"Butller the awesome",
					"Rocky (a dog)" 
					];
var horse = {
	name: "Charlee", color : []
	}; 
horse.color.push("black")
		// return
var warDogs = function(name){ //private
	var food = [ ];
	var hungry = function(full){
		food.push(full)
	};
	return { //public
		"name" : name,
		"color" : ["black"],
		"hungry" : hungry

		};
	};
var diablo = warDogs("diablo")
var malo   = warDogs("malo")

function death() {
	console.log("I get into the King's Chambers and I take out my " + dagger)
	console.log("but one of the elite guards the one with white armor hear me and try to shoot me with his " + eliteguards.eliteWeapons[01])
	console.log("I was able to dogged the bolt and take out my " + bow + " and shoot him in the head.")
	console.log("The second elite guard heard the scream of his commarade and enter the king's chamber so I had to take the king " + king + " and use him as a shield.")
	console.log("this one was on black armor and shoot the king on his heart; I was confuse this was a SET UP!!!!! ")
	};

for ( var i = 0; i < 2; i++ )
console.log(nickname);
console.log("Yes, I like my nickname that's why I always say it twice but my name is John.")
console.log("My mission is to kill the king " + king + ". There are a lot of people guarding " 
     		+ castle + ". For his personal protection the king " + king + 
			" has two elite guards with him at all times.");
												//math
console.log("My client gives me this intel: " + guards*30 + " guards on the main entrance and some info about the elite guards.")
console.log(eliteguards);
// boolean
if (manyguards === true) 
{
	console.log ( "there are many guards, I have to keep noise to a minimun.")
	} 
	 else 
	console.log( "There are not many guards, I can even sing \"It's raing man\" and nobody would hear me." );

// function
death();
// while loop
var i = 0;
while(i < 3){
console.log("OH MAN!!!");
i++;
};
console.log("Then he said to me:")

// JSON
var info = function (json) {
	console.log(json)
	};
	
info(json2)

console.log("He knows too much information about me... why?. I'm better off killing him and fast fast and scape");
console.log("after a long fight I was able to scape, I couldn't kill the elite guard and I speare the life of " + peopleIspeare + ". then, I ride my horse ");
console.log(horse);

console.log("I turn my back to see if anyone was following me but I just saw a wardog in the distace.");
console.log(malo);