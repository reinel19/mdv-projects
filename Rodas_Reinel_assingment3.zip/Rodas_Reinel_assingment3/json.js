var json = {
	"assassin" : {
		"name" : "John",
		"age"  : 27,
		"weapons" : [
		"Azurah's Dagger",
		"Elf Bow"
		]
		}
	};
for (var key in json.assassin){
	var assassin = json.assassin[key];
	}

var json2 = {
	"name" : "John",
	"Age"  : 27,
	"City" : "Altmor",
	"weapons" : [
		"Azurah's Dagger",
		"Elf Bow"
		]
};