// 2013/06/13
// Author Reinel Rodas
// Project #2 (deliverable #2)

var players = ["John", "Ricardo", "Mike"];
var mainPlayer = "John"
var timePlayed = [90, 60, 30]
	console.log ( "Today " + players + " played for " + timePlayed + " minutes.")
;

var johnMinutes = function (overTime) {
	if (overTime > 100) {
		console.log("John played overtime")
	}else{ console.log("John did not play ovetime")
		}
		
};

johnMinutes = 90


var players = ["John",
				"Ricardo",
				"Mike"]
;
for ( var i=0; i < 3; i++ ) {
console.log ( players [i] );
};

console.log( players + " played great today but " + players.push(Reinel) + " made the GOAL."