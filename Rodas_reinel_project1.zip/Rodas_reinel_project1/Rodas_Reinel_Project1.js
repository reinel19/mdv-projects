// 2013/06/04
// Author Reinel Rodas
// Project #1 (deliverable #1)

var johnHasTheBall = true, defences = true, intercepted = true;

if (johnHasTheBall === true) { 
	console.log("Yes, Im going to score.");
	if (defences === true) {
		console.log("I have to pass the ball and give support.")
	} else {
		console.log("I'm going to shoot and score.")
	}; 
} else {
	console.log("I have to get the ball and shoot.");
	if (intercepted === true) {
		console.log("I have to get it back and shoot again")
	} else { 
		console.log("I'm going to score")
	};
}
;